# native-engine
`DeepMindQuantumEngine.kt` is the native Kotlin/Coroutines engine (StateFlow + kotlinx.serialization).
The Expo app runs `src/engine.ts`, a line-for-line port of the same formulas, because Expo's managed build
cannot compile loose Kotlin files. To use the .kt directly, run `npx expo prebuild`, copy it into
`android/app/src/main/java/com/cse/mind/quantum/engine/`, add `kotlinx-serialization` + coroutines to Gradle,
and expose it through a React Native native module — or consume it from a pure Jetpack Compose app.

## Data
The app reads the unofficial cse.lk JSON API (`/tradeSummary`, `/aspi`, `/chartData`, `/companyInfoVideo`).
It has no EPS/NAV or CBSL/FX data, so those are entered in the app. Daily closes are also archived on-device.
