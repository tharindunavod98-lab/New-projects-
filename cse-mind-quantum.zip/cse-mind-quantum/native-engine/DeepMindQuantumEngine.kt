package com.cse.mind.quantum.engine

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.doubleOrNull
import kotlinx.serialization.json.jsonArray
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.put
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/* ---------- Models (serializable straight into Compose UI state) ---------- */

@Serializable
data class StockData(
    val symbol: String, val name: String, val price: Double, val prevClose: Double,
    val history: List<Double>, val eps: Double? = null, val bvps: Double? = null,
    val dps: Double? = null, val isIndex: Boolean = false,
)

@Serializable data class Macro(val cbslRate: Double, val usdLkr: Double, val usdLkrPrev: Double)

@Serializable
data class Technicals(
    val rsi: Double, val macd: Double, val macdSignal: Double, val macdHist: Double,
    val ema20: Double, val ema50: Double, val ema200: Double,
    val support: Double, val resistance: Double, val volatility: Double,
)

@Serializable
data class Fundamentals(
    val pe: Double, val pb: Double, val dividendYield: Double, val roe: Double, val navDiscount: Double,
)

@Serializable
data class Sentiment(val score: Double, val summaryEn: String, val summarySi: String)

@Serializable
data class Analysis(
    val symbol: String, val technicals: Technicals, val fundamentals: Fundamentals?,
    val rating: String, val score: Int, val confidence: Double,
    val stopLoss: Double, val target: Double, val reasons: List<String>, val sentiment: Sentiment?,
)

@Serializable
data class EngineUiState(
    val loading: Boolean = false,
    val results: Map<String, Analysis> = emptyMap(),
    val error: String? = null,
)

/* ---------- Technical indicators ---------- */

object TechnicalIndicators {
    fun ema(v: List<Double>, p: Int): List<Double> {
        val k = 2.0 / (p + 1); val out = ArrayList<Double>(v.size)
        v.forEachIndexed { i, x -> out.add(if (i == 0) x else x * k + out[i - 1] * (1 - k)) }
        return out
    }

    fun rsi(v: List<Double>, p: Int = 14): Double {
        if (v.size <= p) return 50.0
        var g = 0.0; var l = 0.0
        for (i in 1..p) { val d = v[i] - v[i - 1]; if (d >= 0) g += d else l -= d }
        g /= p; l /= p
        for (i in p + 1 until v.size) {
            val d = v[i] - v[i - 1]
            g = (g * (p - 1) + max(d, 0.0)) / p
            l = (l * (p - 1) + max(-d, 0.0)) / p
        }
        return if (l == 0.0) 100.0 else 100.0 - 100.0 / (1 + g / l)
    }

    fun macd(v: List<Double>): Triple<Double, Double, Double> {
        val e12 = ema(v, 12); val e26 = ema(v, 26)
        val line = v.indices.map { e12[it] - e26[it] }
        val sig = ema(line, 9); val i = v.lastIndex
        return Triple(line[i], sig[i], line[i] - sig[i])
    }

    fun levels(v: List<Double>, window: Int = 60): Pair<Double, Double> {
        val s = v.takeLast(window); val lo = ArrayList<Double>(); val hi = ArrayList<Double>()
        for (i in 2 until s.size - 2) {
            if (s[i] < s[i - 1] && s[i] < s[i - 2] && s[i] < s[i + 1] && s[i] < s[i + 2]) lo.add(s[i])
            if (s[i] > s[i - 1] && s[i] > s[i - 2] && s[i] > s[i + 1] && s[i] > s[i + 2]) hi.add(s[i])
        }
        val p = v.last()
        val support = (lo.filter { it <= p } + s.min()).max()
        val resistance = (hi.filter { it >= p } + s.max()).min()
        return support to resistance
    }

    fun volatilityIndex(v: List<Double>, n: Int = 30): Double {
        val s = v.takeLast(n + 1); if (s.size < 3) return 0.0
        val r = (1 until s.size).map { ln(s[it] / s[it - 1]) }
        val m = r.average()
        val sd = sqrt(r.sumOf { (it - m) * (it - m) } / (r.size - 1))
        return sd * sqrt(252.0) * 100
    }

    fun compute(v: List<Double>): Technicals {
        val (m, s, h) = macd(v); val (sup, res) = levels(v)
        return Technicals(rsi(v), m, s, h, ema(v, 20).last(), ema(v, 50).last(), ema(v, 200).last(),
            sup, res, volatilityIndex(v))
    }
}

/* ---------- Fundamentals ---------- */

object FundamentalAnalyzer {
    fun compute(s: StockData): Fundamentals? {
        val eps = s.eps; val bv = s.bvps
        if (s.isIndex || eps == null || bv == null || eps == 0.0 || bv == 0.0) return null
        return Fundamentals(
            pe = s.price / eps, pb = s.price / bv,
            dividendYield = (s.dps ?: 0.0) / s.price * 100,
            roe = eps / bv * 100, navDiscount = (s.price / bv - 1) * 100,
        )
    }
}

/* ---------- Gemini (REST) ---------- */

class GeminiClient(private val apiKey: String, private val model: String = "gemini-flash-latest") {
    suspend fun sentiment(symbol: String, disclosure: String): Sentiment = withContext(Dispatchers.IO) {
        val prompt = """You are a Colombo Stock Exchange analyst. Assess the sentiment of this disclosure for $symbol.
Return ONLY JSON: {"score": number between -1 and 1, "summaryEn": "2 sentences", "summarySi": "same summary in natural professional Sinhala"}.
Disclosure: ${'"'}${'"'}${'"'}$disclosure${'"'}${'"'}${'"'}"""
        val body = buildJsonObject {
            put("contents", buildJsonArray {
                add(buildJsonObject { put("parts", buildJsonArray { add(buildJsonObject { put("text", prompt) }) }) })
            })
            put("generationConfig", buildJsonObject {
                put("responseMimeType", "application/json"); put("temperature", 0.2)
            })
        }.toString()

        val conn = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey")
            .openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"; conn.doOutput = true
            conn.connectTimeout = 10_000; conn.readTimeout = 30_000
            conn.setRequestProperty("Content-Type", "application/json")
            conn.outputStream.use { it.write(body.toByteArray()) }
            if (conn.responseCode !in 200..299) error("Gemini HTTP ${conn.responseCode}")
            val resp = Json.parseToJsonElement(conn.inputStream.bufferedReader().readText()).jsonObject
            val text = resp["candidates"]!!.jsonArray[0].jsonObject["content"]!!.jsonObject["parts"]!!
                .jsonArray[0].jsonObject["text"]!!.jsonPrimitive.content
                .replace("```json", "").replace("```", "").trim()
            val j: JsonObject = Json.parseToJsonElement(text).jsonObject
            Sentiment(
                score = (j["score"]?.jsonPrimitive?.doubleOrNull ?: 0.0).coerceIn(-1.0, 1.0),
                summaryEn = j["summaryEn"]?.jsonPrimitive?.contentOrNull ?: "",
                summarySi = j["summarySi"]?.jsonPrimitive?.contentOrNull ?: "",
            )
        } finally { conn.disconnect() }
    }
}

/* ---------- Engine ---------- */

class DeepMindQuantumEngine(private val gemini: GeminiClient? = null) {
    private val _state = MutableStateFlow(EngineUiState())
    val state: StateFlow<EngineUiState> = _state.asStateFlow()

    private val json = Json { ignoreUnknownKeys = true; prettyPrint = false }
    fun toJson(a: Analysis): String = json.encodeToString(Analysis.serializer(), a)
    fun fromJson(s: String): Analysis = json.decodeFromString(Analysis.serializer(), s)
    fun stateToJson(): String = json.encodeToString(EngineUiState.serializer(), _state.value)

    /** Analyze many symbols in parallel; each disclosure is scored by Gemini if a client is configured. */
    suspend fun analyzeAll(stocks: List<StockData>, macro: Macro, disclosures: Map<String, String>) {
        _state.value = _state.value.copy(loading = true, error = null)
        var err: String? = null
        val results = coroutineScope {
            stocks.map { s ->
                async(Dispatchers.Default) {
                    val sent = try {
                        gemini?.sentiment(s.symbol, disclosures[s.symbol] ?: disclosures["default"].orEmpty())
                    } catch (e: Exception) { err = "Gemini: ${e.message}"; null }
                    s.symbol to analyze(s, macro, sent)
                }
            }.map { it.await() }
        }.toMap()
        _state.value = EngineUiState(false, _state.value.results + results, err)
    }

    fun analyze(s: StockData, macro: Macro, sentiment: Sentiment? = null): Analysis {
        val t = TechnicalIndicators.compute(if (s.history.size >= 2) s.history else listOf(s.price, s.price)); val f = FundamentalAnalyzer.compute(s)
        var score = 0; val why = ArrayList<String>()
        fun add(n: Int, msg: String) { score += n; why.add("${if (n > 0) "+" else ""}$n  $msg") }

        val n = s.history.size
        if (n < 200) why.add("Only $n daily bars: rules needing more history were skipped")
        if (n >= 15) {
            if (t.rsi < 30) add(2, "RSI %.0f oversold".format(t.rsi))
            else if (t.rsi < 45) add(1, "RSI %.0f soft".format(t.rsi))
            else if (t.rsi > 70) add(-2, "RSI %.0f overbought".format(t.rsi))
        }
        if (n >= 35) add(if (t.macdHist > 0) 1 else -1, if (t.macdHist > 0) "MACD above signal" else "MACD below signal")
        if (n >= 50) add(if (s.price > t.ema50) 1 else -1, if (s.price > t.ema50) "Price above EMA50" else "Price below EMA50")
        if (n >= 200) add(if (t.ema50 > t.ema200) 1 else -1, if (t.ema50 > t.ema200) "EMA50 above EMA200" else "EMA50 below EMA200")
        if (f != null) {
            if (f.pe > 0 && f.pe < 10) add(1, "P/E %.1f cheap".format(f.pe)) else if (f.pe > 18) add(-1, "P/E %.1f rich".format(f.pe))
            if (f.pb < 1) add(1, "P/B %.2f below NAV".format(f.pb))
            if (f.dividendYield > 5) add(1, "Dividend yield %.1f%%".format(f.dividendYield))
            if (f.roe > 15) add(1, "ROE %.1f%%".format(f.roe))
            if (f.dividendYield < macro.cbslRate / 3 && macro.cbslRate > 8) add(-1, "High CBSL rate vs low yield")
        }
        if (macro.usdLkr > macro.usdLkrPrev * 1.01) add(-1, "LKR weakening vs USD")
        sentiment?.let {
            val n = Math.round(it.score * 2).toInt()
            if (n != 0) add(n, "AI announcement sentiment %.2f".format(it.score))
        }

        val rating = when {
            score >= 4 -> "STRONG BUY"; score >= 2 -> "BUY"
            score <= -4 -> "STRONG SELL"; score <= -2 -> "SELL"; else -> "HOLD"
        }
        val stop = max(t.support * 0.99, s.price * 0.92)
        val target = max(t.resistance, s.price + 2 * (s.price - stop))
        return Analysis(s.symbol, t, f, rating, score, min(95.0, 50.0 + abs(score) * 6.0), stop, target, why, sentiment)
    }
}
