import axios from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Macro } from './engine';

// Unofficial JSON API behind cse.lk (undocumented; may change or rate-limit). No sample data is used anywhere.
const api = axios.create({
  baseURL: 'https://www.cse.lk/api', timeout: 15000,
  headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
});

export interface Quote {
  symbol: string; name: string; price: number; prevClose: number; changePct: number;
  high: number; low: number; volume: number; isIndex?: boolean;
}
export const WATCH = ['JKH.N0000', 'COMB.N0000', 'DIAL.N0000', 'HAYL.N0000', 'BIL.N0000'];
export const DEFAULT_MACRO: Macro = { cbslRate: 8, usdLkr: 300, usdLkrPrev: 300 }; // set real values in the app
export interface Fund { eps: number; bvps: number; dps: number }

const num = (x: any) => { const n = Number(x); return isFinite(n) ? n : 0; };

export async function fetchQuotes(): Promise<Quote[]> {
  const r = await api.post('/tradeSummary', '');
  const rows = r.data?.reqTradeSummery;
  if (!Array.isArray(rows)) throw new Error('tradeSummary returned an unexpected shape');
  return rows.filter((x: any) => num(x.price) > 0).map((x: any) => ({
    symbol: String(x.symbol), name: String(x.name ?? x.symbol), price: num(x.price),
    prevClose: num(x.previousClose) || num(x.price), changePct: num(x.percentageChange),
    high: num(x.high), low: num(x.low), volume: num(x.quantity),
  }));
}

export async function fetchIndices(): Promise<Quote[]> {
  const r = await api.post('/aspi', '');
  const rows = r.data?.reqASPIIndices;
  if (!Array.isArray(rows)) return [];
  return rows.filter((x: any) => /ASPI|S&P|SL20/i.test(`${x.symbol} ${x.name}`)).map((x: any) => ({
    symbol: String(x.symbol), name: String(x.name ?? x.symbol), price: num(x.price),
    prevClose: num(x.price) - num(x.change), changePct: num(x.changePercentage),
    high: 0, low: 0, volume: num(x.sharevolume), isIndex: true,
  }));
}

// Daily history from /chartData (period 5 = daily per community docs). Request fields are unverified,
// so the parser is defensive and returns null on anything unexpected.
export async function fetchHistory(symbol: string): Promise<number[] | null> {
  try {
    const r = await api.post('/chartData', `symbol=${encodeURIComponent(symbol)}&period=5`);
    const d = r.data;
    const arr: any[] | undefined = Array.isArray(d) ? d : (Object.values(d ?? {}).find(Array.isArray) as any[] | undefined);
    if (!arr?.length) return null;
    const closes = arr.map(x => num(x.p ?? x.price ?? x.c ?? x.close ?? x.lastTradedPrice)).filter(n => n > 0);
    return closes.length > 1 ? closes : null;
  } catch { return null; }
}

// Headlines of company press articles; Gemini scores these (PDF contents are not read).
export async function fetchHeadlines(symbol: string): Promise<string> {
  try {
    const r = await api.post(`/companyInfoVideo?symbol=${encodeURIComponent(symbol)}`, '');
    const rows = r.data?.reqCompanyArticleInfo;
    return Array.isArray(rows) ? rows.slice(0, 8).map((x: any) => String(x.heading)).join('\n') : '';
  } catch { return ''; }
}

// Local daily-close archive: every app open stores today's close, so EMA/MACD history grows even if /chartData fails.
type Snap = Record<string, Record<string, number>>;
const today = () => new Date().toISOString().slice(0, 10);
export async function loadSnap(): Promise<Snap> {
  try { return JSON.parse((await AsyncStorage.getItem('snap:v1')) ?? '{}'); } catch { return {}; }
}
export async function recordSnap(snap: Snap, quotes: Quote[]): Promise<Snap> {
  const d = today();
  for (const q of quotes) (snap[q.symbol] ??= {})[d] = q.price;
  try { await AsyncStorage.setItem('snap:v1', JSON.stringify(snap)); } catch {}
  return snap;
}
export const snapSeries = (snap: Snap, symbol: string) =>
  Object.entries(snap[symbol] ?? {}).sort(([a], [b]) => a.localeCompare(b)).map(([, v]) => v);

export async function loadPrefs(): Promise<{ macro: Macro; fund: Record<string, Fund> }> {
  try { const p = JSON.parse((await AsyncStorage.getItem('prefs:v1')) ?? '{}');
    return { macro: p.macro ?? DEFAULT_MACRO, fund: p.fund ?? {} }; }
  catch { return { macro: DEFAULT_MACRO, fund: {} }; }
}
export const savePrefs = (macro: Macro, fund: Record<string, Fund>) =>
  AsyncStorage.setItem('prefs:v1', JSON.stringify({ macro, fund })).catch(() => {});
