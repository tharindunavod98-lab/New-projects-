import { create } from 'zustand';
import { Analysis, Macro, Stock, analyze, sinhalaSummary } from './engine';
import { DEFAULT_MACRO, Fund, Quote, fetchHeadlines, fetchHistory, fetchIndices, fetchQuotes, loadPrefs, loadSnap,
  recordSnap, savePrefs, snapSeries } from './data';
import { analyzeAnnouncement, hasGemini } from './gemini';

interface S {
  lang: 'en' | 'si'; quotes: Quote[]; indices: Quote[]; histories: Record<string, number[]>;
  fund: Record<string, Fund>; macro: Macro; snap: Record<string, Record<string, number>>;
  loading: boolean; error: string | null; updated: string | null; signals: Record<string, Analysis>;
  setLang: (l: 'en' | 'si') => void; setMacro: (m: Macro) => void; setFund: (sym: string, f: Fund) => void;
  load: () => Promise<void>; loadHistory: (sym: string) => Promise<void>; generate: (sym: string) => Promise<void>;
}

export function buildStock(s: S, sym: string): Stock | null {
  const q = s.quotes.find(x => x.symbol === sym) ?? s.indices.find(x => x.symbol === sym); if (!q) return null;
  const f = s.fund[sym];
  return { symbol: q.symbol, name: q.name, price: q.price, prevClose: q.prevClose,
    history: s.histories[sym] ?? snapSeries(s.snap, sym), isIndex: q.isIndex, eps: f?.eps, bvps: f?.bvps, dps: f?.dps };
}

export const useStore = create<S>((set, get) => ({
  lang: 'en', quotes: [], indices: [], histories: {}, fund: {}, macro: DEFAULT_MACRO, snap: {},
  loading: false, error: null, updated: null, signals: {},
  setLang: lang => set({ lang }),
  setMacro: macro => { set({ macro }); savePrefs(macro, get().fund); },
  setFund: (sym, f) => { const fund = { ...get().fund, [sym]: f }; set({ fund }); savePrefs(get().macro, fund); },
  load: async () => {
    set({ loading: true, error: null });
    try {
      const [prefs, snap0] = await Promise.all([loadPrefs(), loadSnap()]);
      const [quotes, indices] = await Promise.all([fetchQuotes(), fetchIndices().catch(() => [])]);
      const snap = await recordSnap(snap0, [...quotes, ...indices]);
      set({ quotes, indices, snap, macro: prefs.macro, fund: prefs.fund, updated: new Date().toLocaleTimeString(), loading: false });
    } catch (e: any) {
      set({ loading: false, error: `Could not reach CSE (${e?.message ?? 'network error'}). Pull down to retry.` });
    }
  },
  loadHistory: async sym => {
    if (get().histories[sym]) return;
    const h = await fetchHistory(sym);
    if (h) set(st => ({ histories: { ...st.histories, [sym]: h } }));
  },
  generate: async sym => {
    set({ loading: true, error: null });
    await get().loadHistory(sym);
    const stock = buildStock(get(), sym); if (!stock) { set({ loading: false, error: 'No quote for ' + sym }); return; }
    let sentiment: Analysis['sentiment'] = null; let note: string | null = null;
    const text = await fetchHeadlines(sym);
    if (!hasGemini) note = 'No Gemini key set — rule-based result only.';
    else if (!text) note = 'No recent company announcements found — sentiment skipped.';
    else { try { sentiment = await analyzeAnnouncement(sym, text); } catch (e: any) { note = 'Gemini failed: ' + (e?.message ?? ''); } }
    const a = analyze(stock, get().macro, sentiment);
    if (!a.sentiment) a.sentiment = { score: 0, summaryEn: `${stock.name}: ${a.rating} (score ${a.score}).`, summarySi: sinhalaSummary(a, stock.name) };
    set(st => ({ loading: false, error: note, signals: { ...st.signals, [sym]: a } }));
  },
}));
