import { GoogleGenerativeAI } from '@google/generative-ai';
import { Sentiment } from './engine';

const KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY;
const MODEL = process.env.EXPO_PUBLIC_GEMINI_MODEL || 'gemini-flash-latest';
export const hasGemini = !!KEY;

export async function analyzeAnnouncement(symbol: string, text: string): Promise<Sentiment> {
  if (!KEY) throw new Error('Missing EXPO_PUBLIC_GEMINI_API_KEY');
  const model = new GoogleGenerativeAI(KEY).getGenerativeModel({
    model: MODEL, generationConfig: { responseMimeType: 'application/json', temperature: 0.2 },
  });
  const prompt = `You are a Colombo Stock Exchange analyst. Assess the sentiment of this disclosure for ${symbol}.
Return ONLY JSON: {"score": number between -1 and 1, "summaryEn": "2 sentences", "summarySi": "same summary in natural professional Sinhala"}.
Disclosure: """${text}"""`;
  const res = await model.generateContent(prompt);
  const j = JSON.parse(res.response.text().replace(/```json|```/g, '').trim());
  return { score: Math.max(-1, Math.min(1, Number(j.score) || 0)), summaryEn: String(j.summaryEn), summarySi: String(j.summarySi) };
}
