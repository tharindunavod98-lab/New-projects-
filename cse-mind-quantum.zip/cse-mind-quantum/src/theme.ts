export const C = {
  bg: '#0D1117', card: '#161B22', border: '#262D36',
  green: '#00E676', red: '#FF5252', amber: '#FFC400',
  text: '#E6EDF3', dim: '#8B949E',
};
