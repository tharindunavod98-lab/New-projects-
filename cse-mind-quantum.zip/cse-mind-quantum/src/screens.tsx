import React, { useEffect, useState } from 'react';
import { ActivityIndicator, FlatList, Pressable, RefreshControl, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Rating, analyze } from './engine';
import { WATCH } from './data';
import { buildStock, useStore } from './store';
import { C } from './theme';

const ratingColor = (r: Rating) => (r.includes('BUY') ? C.green : r.includes('SELL') ? C.red : C.amber);
const Card = ({ children, style }: any) => <View style={[st.card, style]}>{children}</View>;
const Kv = ({ k, v, color }: { k: string; v: string; color?: string }) => (
  <View style={st.kv}><Text style={st.dim}>{k}</Text><Text style={[st.val, color ? { color } : null]}>{v}</Text></View>
);
const Field = ({ l, v, set }: { l: string; v: string; set: (s: string) => void }) => (
  <View style={st.kv}><Text style={st.dim}>{l}</Text>
    <TextInput value={v} onChangeText={set} keyboardType="decimal-pad" style={st.input} /></View>
);
const Spark = ({ data }: { data: number[] }) => {
  if (data.length < 2) return <Text style={st.dim}>Chart appears once at least 2 daily closes are stored.</Text>;
  const d = data.slice(-48), lo = Math.min(...d), hi = Math.max(...d);
  return (
    <View style={{ flexDirection: 'row', alignItems: 'flex-end', height: 56, gap: 2 }}>
      {d.map((x, i) => <View key={i} style={{ flex: 1, height: 4 + ((x - lo) / (hi - lo || 1)) * 52,
        backgroundColor: i > 0 && x >= d[i - 1] ? C.green : C.red, borderRadius: 1 }} />)}
    </View>
  );
};

export function Dashboard({ navigation }: any) {
  const { quotes, indices, loading, error, updated, lang, setLang, load } = useStore();
  const [q, setQ] = useState('');
  useEffect(() => { load(); }, []);
  const list = quotes
    .filter(x => `${x.symbol} ${x.name}`.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => {
      const wa = WATCH.indexOf(a.symbol), wb = WATCH.indexOf(b.symbol);
      if (wa >= 0 || wb >= 0) return (wa < 0 ? 99 : wa) - (wb < 0 ? 99 : wb);
      return b.volume - a.volume;
    });
  return (
    <View style={st.screen}>
      <View style={st.head}>
        <View>
          <Text style={st.title}>CSE Mind Quantum</Text>
          <Text style={[st.dim, { color: error ? C.red : C.green }]}>{error ? 'Offline' : updated ? `Live · updated ${updated}` : 'Connecting…'}</Text>
        </View>
        <Pressable style={st.chip} onPress={() => setLang(lang === 'en' ? 'si' : 'en')}>
          <Text style={st.chipT}>{lang === 'en' ? 'සිංහල' : 'English'}</Text>
        </Pressable>
      </View>
      {indices.length > 0 && (
        <View style={{ flexDirection: 'row', gap: 10, paddingHorizontal: 12 }}>
          {indices.map(i => (
            <Card key={i.symbol} style={{ flex: 1 }}>
              <Text style={st.dim}>{i.name}</Text>
              <Text style={st.price}>{i.price.toLocaleString('en-US', { maximumFractionDigits: 2 })}</Text>
              <Text style={{ color: i.changePct >= 0 ? C.green : C.red, fontWeight: '700' }}>{i.changePct >= 0 ? '+' : ''}{i.changePct.toFixed(2)}%</Text>
            </Card>
          ))}
        </View>
      )}
      <TextInput value={q} onChangeText={setQ} placeholder="Search symbol or company" placeholderTextColor={C.dim}
        style={[st.input, { margin: 12, textAlign: 'left' }]} />
      {error && <Text style={{ color: C.red, paddingHorizontal: 12 }}>{error}</Text>}
      <FlatList data={list} keyExtractor={s => s.symbol} contentContainerStyle={{ padding: 12, paddingTop: 0, gap: 10 }}
        refreshControl={<RefreshControl refreshing={loading} onRefresh={load} tintColor={C.green} />}
        ListEmptyComponent={loading ? <ActivityIndicator color={C.green} /> : <Text style={st.dim}>No quotes loaded.</Text>}
        renderItem={({ item: s }) => (
          <Pressable onPress={() => navigation.navigate('StockDetail', { symbol: s.symbol })}>
            <Card>
              <View style={st.row}>
                <View style={{ flex: 1 }}>
                  <Text style={st.sym}>{s.symbol.split('.')[0]}</Text>
                  <Text style={st.dim} numberOfLines={1}>{s.name}</Text>
                </View>
                <View style={{ alignItems: 'flex-end' }}>
                  <Text style={st.price}>{s.price.toLocaleString('en-US', { maximumFractionDigits: 2 })}</Text>
                  <Text style={{ color: s.changePct >= 0 ? C.green : C.red, fontWeight: '700' }}>{s.changePct >= 0 ? '+' : ''}{s.changePct.toFixed(2)}%</Text>
                </View>
              </View>
            </Card>
          </Pressable>
        )} />
    </View>
  );
}

export function StockDetail({ route, navigation }: any) {
  const sym: string = route.params.symbol;
  const S = useStore(); const stock = buildStock(S, sym);
  const f0 = S.fund[sym];
  const [eps, setEps] = useState(f0 ? String(f0.eps) : ''), [bv, setBv] = useState(f0 ? String(f0.bvps) : ''), [dps, setDps] = useState(f0 ? String(f0.dps) : '');
  useEffect(() => { S.loadHistory(sym); }, [sym]);
  if (!stock) return <View style={st.screen}><Text style={[st.dim, { padding: 16 }]}>No quote for {sym}.</Text></View>;
  const a = analyze(stock, S.macro); const t = a.technicals; const f = a.fundamentals; const n = stock.history.length;
  return (
    <ScrollView style={st.screen} contentContainerStyle={{ padding: 12, gap: 10 }}>
      <Card>
        <Text style={st.sym}>{sym}</Text><Text style={st.dim}>{stock.name}</Text>
        <Text style={[st.price, { fontSize: 32, marginVertical: 8 }]}>{stock.price.toFixed(2)}</Text>
        <Spark data={stock.history} />
        <Text style={[st.dim, { marginTop: 6 }]}>{n} daily closes loaded</Text>
      </Card>
      {n < 200 && <Text style={{ color: C.amber }}>Fewer than 200 closes: EMA200 and some signal rules are skipped until more history is available.</Text>}
      {n >= 15 && (
        <Card>
          <Text style={st.h}>Technicals</Text>
          <Kv k="RSI (14)" v={t.rsi.toFixed(1)} color={t.rsi > 70 ? C.red : t.rsi < 30 ? C.green : undefined} />
          {n >= 35 && <Kv k="MACD / Signal" v={`${t.macd.toFixed(3)} / ${t.macdSignal.toFixed(3)}`} color={t.macdHist > 0 ? C.green : C.red} />}
          <Kv k="EMA 20 / 50 / 200" v={`${t.ema20.toFixed(2)} / ${n >= 50 ? t.ema50.toFixed(2) : '–'} / ${n >= 200 ? t.ema200.toFixed(2) : '–'}`} />
          <Kv k="Support" v={t.support.toFixed(2)} color={C.green} />
          <Kv k="Resistance" v={t.resistance.toFixed(2)} color={C.red} />
          <Kv k="Volatility (ann.)" v={`${t.volatility.toFixed(1)}%`} />
        </Card>
      )}
      {!stock.isIndex && (
        <Card>
          <Text style={st.h}>Fundamentals</Text>
          <Text style={[st.dim, { marginBottom: 6 }]}>CSE's feed has no EPS or NAV. Enter them from the latest financial report.</Text>
          <Field l="EPS (last 12 months)" v={eps} set={setEps} /><Field l="Book value / share" v={bv} set={setBv} /><Field l="Dividend / share (12m)" v={dps} set={setDps} />
          <Pressable style={[st.btn, { marginTop: 8 }]} onPress={() => S.setFund(sym, { eps: parseFloat(eps) || 0, bvps: parseFloat(bv) || 0, dps: parseFloat(dps) || 0 })}>
            <Text style={st.btnT}>Save</Text>
          </Pressable>
          {f && (<View style={{ marginTop: 8 }}>
            <Kv k="P/E" v={f.pe.toFixed(1)} /><Kv k="P/B" v={f.pb.toFixed(2)} />
            <Kv k="Dividend yield" v={`${f.dividendYield.toFixed(2)}%`} /><Kv k="ROE" v={`${f.roe.toFixed(1)}%`} />
            <Kv k="Price vs NAV" v={`${f.navDiscount.toFixed(1)}%`} color={f.navDiscount < 0 ? C.green : C.red} />
          </View>)}
        </Card>
      )}
      <Pressable style={st.btn} onPress={() => navigation.navigate('Signals', { symbol: sym })}>
        <Text style={st.btnT}>Generate AI signal</Text>
      </Pressable>
    </ScrollView>
  );
}

export function Signals({ route }: any) {
  const { signals, generate, loading, lang, error, macro, setMacro } = useStore();
  const [sym, setSym] = useState<string>(route?.params?.symbol ?? WATCH[0]);
  const [rate, setRate] = useState(String(macro.cbslRate)), [fx, setFx] = useState(String(macro.usdLkr)), [fxp, setFxp] = useState(String(macro.usdLkrPrev));
  useEffect(() => { if (route?.params?.symbol) setSym(route.params.symbol); }, [route?.params?.symbol]);
  useEffect(() => { setRate(String(macro.cbslRate)); setFx(String(macro.usdLkr)); setFxp(String(macro.usdLkrPrev)); }, [macro]);
  const a = signals[sym];
  const chips = WATCH.includes(sym) ? WATCH : [sym, ...WATCH];
  return (
    <ScrollView style={st.screen} contentContainerStyle={{ padding: 12, gap: 10 }}>
      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ gap: 8 }}>
        {chips.map(s => (
          <Pressable key={s} style={[st.chip, sym === s && { backgroundColor: C.green }]} onPress={() => setSym(s)}>
            <Text style={[st.chipT, sym === s && { color: C.bg }]}>{s.split('.')[0]}</Text>
          </Pressable>
        ))}
      </ScrollView>
      <Card>
        <Text style={st.h}>Macro inputs (from CBSL)</Text>
        <Field l="Policy rate %" v={rate} set={setRate} /><Field l="USD/LKR today" v={fx} set={setFx} /><Field l="USD/LKR last week" v={fxp} set={setFxp} />
        <Pressable style={[st.btn, { marginTop: 8 }]} onPress={() => setMacro({ cbslRate: parseFloat(rate) || 0, usdLkr: parseFloat(fx) || 0, usdLkrPrev: parseFloat(fxp) || 0 })}>
          <Text style={st.btnT}>Save macro</Text>
        </Pressable>
      </Card>
      <Pressable style={st.btn} onPress={() => generate(sym)} disabled={loading}>
        {loading ? <ActivityIndicator color={C.bg} /> : <Text style={st.btnT}>Generate signal</Text>}
      </Pressable>
      {error && <Text style={{ color: C.amber }}>{error}</Text>}
      {a && (
        <>
          <Card>
            <Text style={[st.rating, { color: ratingColor(a.rating) }]}>{a.rating}</Text>
            <Text style={st.dim}>Confidence {a.confidence.toFixed(0)}% · score {a.score}</Text>
            <View style={{ height: 8 }} />
            <Kv k="Target" v={a.target.toFixed(2)} color={C.green} />
            <Kv k="Stop-loss" v={a.stopLoss.toFixed(2)} color={C.red} />
          </Card>
          <Card>
            <Text style={st.h}>{lang === 'si' ? 'AI සාරාංශය' : 'AI summary'}</Text>
            <Text style={[st.body, lang === 'si' && { lineHeight: 26 }]}>{lang === 'si' ? a.sentiment?.summarySi : a.sentiment?.summaryEn}</Text>
          </Card>
          <Card>
            <Text style={st.h}>Why</Text>
            {a.reasons.map((r, i) => <Text key={i} style={st.body}>{r}</Text>)}
          </Card>
          <Text style={st.dim}>Not investment advice. Signals are model outputs.</Text>
        </>
      )}
    </ScrollView>
  );
}

export function Calculator() {
  const [cap, setCap] = useState('1000000'), [risk, setRisk] = useState('1'), [entry, setEntry] = useState('20'),
    [stopPct, setStopPct] = useState('6'), [rr, setRr] = useState('2'), [fee, setFee] = useState('1.12');
  const n = (x: string) => parseFloat(x) || 0;
  const stop = n(entry) * (1 - n(stopPct) / 100), perShare = n(entry) - stop;
  const riskAmt = n(cap) * n(risk) / 100;
  const shares = perShare > 0 ? Math.floor(riskAmt / perShare) : 0;
  const target = n(entry) + perShare * n(rr);
  const cost = shares * n(entry), feeAmt = cost * n(fee) / 100 * 2;
  const reward = shares * (target - n(entry)) - feeAmt;
  const F = ({ l, v, set }: any) => (
    <View style={st.kv}><Text style={st.dim}>{l}</Text>
      <TextInput value={v} onChangeText={set} keyboardType="decimal-pad" style={st.input} /></View>
  );
  return (
    <ScrollView style={st.screen} contentContainerStyle={{ padding: 12, gap: 10 }}>
      <Card>
        <F l="Capital (LKR)" v={cap} set={setCap} /><F l="Risk per trade %" v={risk} set={setRisk} />
        <F l="Entry price" v={entry} set={setEntry} /><F l="Stop distance %" v={stopPct} set={setStopPct} />
        <F l="Reward : risk" v={rr} set={setRr} /><F l="Round-trip fee % per side" v={fee} set={setFee} />
      </Card>
      <Card>
        <Kv k="Shares to buy" v={shares.toLocaleString()} />
        <Kv k="Position cost" v={`LKR ${cost.toLocaleString('en-US', { maximumFractionDigits: 0 })}`} />
        <Kv k="Stop-loss price" v={stop.toFixed(2)} color={C.red} />
        <Kv k="Target price" v={target.toFixed(2)} color={C.green} />
        <Kv k="Max loss" v={`LKR ${riskAmt.toLocaleString('en-US', { maximumFractionDigits: 0 })}`} color={C.red} />
        <Kv k="Net reward after fees" v={`LKR ${reward.toLocaleString('en-US', { maximumFractionDigits: 0 })}`} color={C.green} />
      </Card>
    </ScrollView>
  );
}

const st = StyleSheet.create({
  screen: { flex: 1, backgroundColor: C.bg },
  head: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 16, paddingTop: 48 },
  title: { color: C.text, fontSize: 22, fontWeight: '800' },
  card: { backgroundColor: C.card, borderRadius: 12, padding: 14, borderWidth: 1, borderColor: C.border },
  row: { flexDirection: 'row', alignItems: 'center' },
  sym: { color: C.text, fontSize: 18, fontWeight: '800' },
  price: { color: C.text, fontSize: 18, fontWeight: '700' },
  dim: { color: C.dim, fontSize: 13 },
  h: { color: C.text, fontSize: 16, fontWeight: '700', marginBottom: 8 },
  body: { color: C.text, fontSize: 15, lineHeight: 22, marginBottom: 2 },
  kv: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 5 },
  val: { color: C.text, fontWeight: '600', fontSize: 14 },
  chip: { backgroundColor: C.card, borderWidth: 1, borderColor: C.border, paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20 },
  chipT: { color: C.text, fontWeight: '700' },
  btn: { backgroundColor: C.green, padding: 14, borderRadius: 10, alignItems: 'center' },
  btnT: { color: C.bg, fontWeight: '800', fontSize: 16 },
  rating: { fontSize: 30, fontWeight: '900' },
  input: { color: C.text, backgroundColor: C.bg, borderWidth: 1, borderColor: C.border, borderRadius: 8, minWidth: 110, padding: 8, textAlign: 'right' },
});
