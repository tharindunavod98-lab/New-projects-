// TypeScript runtime port of native-engine/DeepMindQuantumEngine.kt (same formulas).
export interface Stock {
  symbol: string; name: string; price: number; prevClose: number; history: number[];
  eps?: number; bvps?: number; dps?: number; isIndex?: boolean;
}
export interface Macro { cbslRate: number; usdLkr: number; usdLkrPrev: number }
export interface Sentiment { score: number; summaryEn: string; summarySi: string }
export type Rating = 'STRONG BUY' | 'BUY' | 'HOLD' | 'SELL' | 'STRONG SELL';
export interface Technicals {
  rsi: number; macd: number; macdSignal: number; macdHist: number;
  ema20: number; ema50: number; ema200: number; support: number; resistance: number; volatility: number;
}
export interface Fundamentals {
  pe: number; pb: number; dividendYield: number; roe: number; navDiscount: number;
}
export interface Analysis {
  symbol: string; technicals: Technicals; fundamentals: Fundamentals | null;
  rating: Rating; score: number; confidence: number; stopLoss: number; target: number;
  reasons: string[]; sentiment: Sentiment | null;
}

export const ema = (v: number[], p: number): number[] => {
  const k = 2 / (p + 1); const out: number[] = [];
  v.forEach((x, i) => out.push(i === 0 ? x : x * k + out[i - 1] * (1 - k)));
  return out;
};

export function rsi(v: number[], p = 14): number {
  if (v.length <= p) return 50;
  let g = 0, l = 0;
  for (let i = 1; i <= p; i++) { const d = v[i] - v[i - 1]; if (d >= 0) g += d; else l -= d; }
  g /= p; l /= p;
  for (let i = p + 1; i < v.length; i++) {
    const d = v[i] - v[i - 1];
    g = (g * (p - 1) + Math.max(d, 0)) / p;
    l = (l * (p - 1) + Math.max(-d, 0)) / p;
  }
  return l === 0 ? 100 : 100 - 100 / (1 + g / l);
}

export function macd(v: number[]) {
  const e12 = ema(v, 12), e26 = ema(v, 26);
  const line = v.map((_, i) => e12[i] - e26[i]);
  const sig = ema(line, 9); const i = v.length - 1;
  return { macd: line[i], signal: sig[i], hist: line[i] - sig[i] };
}

export function levels(v: number[], window = 60) {
  const s = v.slice(-window); const lo: number[] = [], hi: number[] = [];
  for (let i = 2; i < s.length - 2; i++) {
    if (s[i] < s[i - 1] && s[i] < s[i - 2] && s[i] < s[i + 1] && s[i] < s[i + 2]) lo.push(s[i]);
    if (s[i] > s[i - 1] && s[i] > s[i - 2] && s[i] > s[i + 1] && s[i] > s[i + 2]) hi.push(s[i]);
  }
  const p = v[v.length - 1];
  const support = Math.max(...lo.filter(x => x <= p), Math.min(...s));
  const resistance = Math.min(...hi.filter(x => x >= p), Math.max(...s));
  return { support, resistance };
}

export function volatilityIndex(v: number[], n = 30): number {
  const s = v.slice(-(n + 1)); if (s.length < 3) return 0;
  const r = s.slice(1).map((x, i) => Math.log(x / s[i]));
  const m = r.reduce((a, b) => a + b, 0) / r.length;
  const sd = Math.sqrt(r.reduce((a, b) => a + (b - m) ** 2, 0) / (r.length - 1));
  return sd * Math.sqrt(252) * 100;
}

export function technicals(v: number[]): Technicals {
  const m = macd(v); const lv = levels(v); const last = (a: number[]) => a[a.length - 1];
  return {
    rsi: rsi(v), macd: m.macd, macdSignal: m.signal, macdHist: m.hist,
    ema20: last(ema(v, 20)), ema50: last(ema(v, 50)), ema200: last(ema(v, 200)),
    support: lv.support, resistance: lv.resistance, volatility: volatilityIndex(v),
  };
}

export function fundamentals(s: Stock): Fundamentals | null {
  if (s.isIndex || !s.eps || !s.bvps) return null;
  return {
    pe: s.price / s.eps, pb: s.price / s.bvps,
    dividendYield: ((s.dps ?? 0) / s.price) * 100, roe: (s.eps / s.bvps) * 100,
    navDiscount: (s.price / s.bvps - 1) * 100,
  };
}

export function analyze(s: Stock, macro: Macro, sentiment: Sentiment | null = null): Analysis {
  const n = s.history.length;
  const t = technicals(n >= 2 ? s.history : [s.price, s.price]); const f = fundamentals(s);
  let score = 0; const why: string[] = [];
  const add = (k: number, msg: string) => { score += k; why.push(`${k > 0 ? '+' : ''}${k}  ${msg}`); };

  if (n < 200) why.push(`Only ${n} daily bars: rules needing more history were skipped`);
  if (n >= 15) {
    if (t.rsi < 30) add(2, `RSI ${t.rsi.toFixed(0)} oversold`);
    else if (t.rsi < 45) add(1, `RSI ${t.rsi.toFixed(0)} soft`);
    else if (t.rsi > 70) add(-2, `RSI ${t.rsi.toFixed(0)} overbought`);
  }
  if (n >= 35) add(t.macdHist > 0 ? 1 : -1, t.macdHist > 0 ? 'MACD above signal' : 'MACD below signal');
  if (n >= 50) add(s.price > t.ema50 ? 1 : -1, s.price > t.ema50 ? 'Price above EMA50' : 'Price below EMA50');
  if (n >= 200) add(t.ema50 > t.ema200 ? 1 : -1, t.ema50 > t.ema200 ? 'EMA50 above EMA200' : 'EMA50 below EMA200');
  if (f) {
    if (f.pe > 0 && f.pe < 10) add(1, `P/E ${f.pe.toFixed(1)} cheap`);
    else if (f.pe > 18) add(-1, `P/E ${f.pe.toFixed(1)} rich`);
    if (f.pb < 1) add(1, `P/B ${f.pb.toFixed(2)} below NAV`);
    if (f.dividendYield > 5) add(1, `Dividend yield ${f.dividendYield.toFixed(1)}%`);
    if (f.roe > 15) add(1, `ROE ${f.roe.toFixed(1)}%`);
    if (f.dividendYield < macro.cbslRate / 3 && macro.cbslRate > 8) add(-1, 'High CBSL rate vs low yield');
  }
  if (macro.usdLkr > macro.usdLkrPrev * 1.01) add(-1, 'LKR weakening vs USD');
  if (sentiment) {
    const k = Math.round(sentiment.score * 2);
    if (k !== 0) add(k, `AI announcement sentiment ${sentiment.score.toFixed(2)}`);
  }

  const rating: Rating = score >= 4 ? 'STRONG BUY' : score >= 2 ? 'BUY' : score <= -4 ? 'STRONG SELL' : score <= -2 ? 'SELL' : 'HOLD';
  const stopLoss = Math.max(t.support * 0.99, s.price * 0.92);
  const target = Math.max(t.resistance, s.price + 2 * (s.price - stopLoss));
  return {
    symbol: s.symbol, technicals: t, fundamentals: f, rating, score,
    confidence: Math.min(95, 50 + Math.abs(score) * 6), stopLoss, target, reasons: why, sentiment,
  };
}

export function sinhalaSummary(a: Analysis, name: string): string {
  const r: Record<Rating, string> = {
    'STRONG BUY': 'ප්‍රබල මිලදී ගැනීමේ සංඥාවකි', 'BUY': 'මිලදී ගැනීමට සුදුසු සංඥාවකි',
    'HOLD': 'රඳවා ගැනීම (Hold) සුදුසුයි', 'SELL': 'විකිණීමට සුදුසු සංඥාවකි',
    'STRONG SELL': 'ප්‍රබල විකිණීමේ සංඥාවකි',
  };
  return `${name} සඳහා වත්මන් විශ්ලේෂණය: ${r[a.rating]}. විශ්වාසනීයත්වය ${a.confidence.toFixed(0)}%. ` +
    `RSI අගය ${a.technicals.rsi.toFixed(0)} වේ. ලාභ ඉලක්කය රු. ${a.target.toFixed(2)} ද, ස්ටොප් ලොස් රු. ${a.stopLoss.toFixed(2)} ද වේ. ` +
    `මෙය ආයෝජන උපදෙසක් නොවේ.`;
}
