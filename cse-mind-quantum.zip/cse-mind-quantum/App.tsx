import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer, DarkTheme } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { Ionicons } from '@expo/vector-icons';
import { Calculator, Dashboard, Signals, StockDetail } from './src/screens';
import { C } from './src/theme';

const Tab = createBottomTabNavigator();
const Stack = createNativeStackNavigator();
const theme = { ...DarkTheme, colors: { ...DarkTheme.colors, background: C.bg, card: C.card, text: C.text, border: C.border, primary: C.green } };

function MarketStack() {
  return (
    <Stack.Navigator screenOptions={{ headerStyle: { backgroundColor: C.card }, headerTintColor: C.text }}>
      <Stack.Screen name="Dashboard" component={Dashboard} options={{ headerShown: false }} />
      <Stack.Screen name="StockDetail" component={StockDetail} options={{ title: 'Stock detail' }} />
    </Stack.Navigator>
  );
}
const icon = (n: any) => ({ tabBarIcon: ({ color, size }: any) => <Ionicons name={n} color={color} size={size} /> });

export default function App() {
  return (
    <NavigationContainer theme={theme}>
      <StatusBar style="light" />
      <Tab.Navigator screenOptions={{ headerShown: false, tabBarActiveTintColor: C.green, tabBarInactiveTintColor: C.dim,
        tabBarStyle: { backgroundColor: C.card, borderTopColor: C.border } }}>
        <Tab.Screen name="Market" component={MarketStack} options={icon('trending-up')} />
        <Tab.Screen name="Signals" component={Signals} options={icon('sparkles')} />
        <Tab.Screen name="Calculator" component={Calculator} options={{ ...icon('calculator'), headerShown: true,
          headerStyle: { backgroundColor: C.card }, headerTintColor: C.text, title: 'Target / Stop-loss' }} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
